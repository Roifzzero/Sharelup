package com.sharelup.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Patterns;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int PORT = 8888;
    private static final int BUF = 64 * 1024;
    private static final int MAGIC = 0x53484C50;
    private static final int REQ_PICK = 11;
    private static final int REQ_PERM = 12;
    private static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int C_BLUE = 0xFF1E6FD9;
    private static final int C_GREEN = 0xFF1E9E5A;
    private static final int C_RED = 0xFFD64545;
    private static final int C_GRAY = 0xFF5B6B7C;
    private static final int C_TEXT = 0xFF1A2B3C;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean receiving = false;
    private volatile boolean sending = false;
    private volatile boolean cancel = false;
    private volatile ServerSocket server;
    private volatile Socket active;
    private long lastUi = 0;

    private TextView tvIp, tvStatus, tvDetail;
    private ProgressBar bar;
    private EditText etIp;
    private Button btnReceive, btnAuto, btnSend;

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshIp();
        if (etIp.getText().toString().trim().isEmpty()) {
            etIp.setText(gateway());
        }
    }

    @Override
    protected void onDestroy() {
        receiving = false;
        cancel = true;
        closeQuiet(server);
        closeQuiet(active);
        super.onDestroy();
    }

    // ------------------------------------------------------------ UI

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFF2F5F9);
        sv.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(MP, WC));

        root.addView(text("Sharelup", 30, C_BLUE, true));
        root.addView(text("Kirim file antar HP tanpa internet", 14, C_GRAY, false));

        LinearLayout c1 = card(root);
        c1.addView(text("TERIMA FILE", 12, C_GRAY, true));
        tvIp = text("", 15, C_TEXT, false);
        tvIp.setPadding(0, dp(6), 0, dp(4));
        c1.addView(tvIp);
        btnReceive = button("MULAI TERIMA", C_GREEN);
        btnReceive.setOnClickListener(v -> toggleReceive());
        c1.addView(btnReceive, lp(52, 10));

        LinearLayout c2 = card(root);
        c2.addView(text("KIRIM FILE", 12, C_GRAY, true));
        etIp = new EditText(this);
        etIp.setHint("IP HP penerima, mis. 192.168.43.1");
        etIp.setSingleLine(true);
        etIp.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        c2.addView(etIp, lp(WC, 4));
        btnAuto = button("ISI IP OTOMATIS", C_GRAY);
        btnAuto.setOnClickListener(v -> {
            String g = gateway();
            if (g.isEmpty()) {
                toast("Tidak terdeteksi. Ketik IP yang tampil di HP penerima.");
            } else {
                etIp.setText(g);
            }
        });
        c2.addView(btnAuto, lp(46, 8));
        btnSend = button("PILIH FILE & KIRIM", C_BLUE);
        btnSend.setOnClickListener(v -> onSendClick());
        c2.addView(btnSend, lp(52, 10));

        LinearLayout c3 = card(root);
        c3.addView(text("STATUS", 12, C_GRAY, true));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        c3.addView(bar, lp(WC, 8));
        tvStatus = text("Siap", 16, C_TEXT, true);
        c3.addView(tvStatus, lp(WC, 6));
        tvDetail = text("", 13, C_GRAY, false);
        c3.addView(tvDetail, lp(WC, 2));

        LinearLayout c4 = card(root);
        c4.addView(text("CARA PAKAI", 12, C_GRAY, true));
        TextView tips = text(
                "1. HP penerima: nyalakan Hotspot, buka Sharelup, tekan MULAI TERIMA.\n"
                        + "2. HP pengirim: sambungkan Wi-Fi ke hotspot itu, buka Sharelup.\n"
                        + "3. Tekan ISI IP OTOMATIS, lalu PILIH FILE & KIRIM.\n\n"
                        + "File masuk ke folder Download/Sharelup. Biarkan layar tetap menyala "
                        + "sampai transfer selesai.", 13, C_TEXT, false);
        tips.setPadding(0, dp(6), 0, 0);
        c4.addView(tips);

        setContentView(sv);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams lp(int heightDp, int topDp) {
        int h = heightDp == WC ? WC : dp(heightDp);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MP, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFFFFFFFF);
        g.setCornerRadius(dp(16));
        c.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MP, WC);
        p.topMargin = dp(14);
        parent.addView(c, p);
        return c;
    }

    private Button button(String t, int color) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        b.setStateListAnimator(null);
        paint(b, color);
        return b;
    }

    private void paint(Button b, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(12));
        b.setBackground(g);
    }

    private void enable(Button b, boolean on) {
        b.setEnabled(on);
        b.setAlpha(on ? 1f : 0.45f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void refreshIp() {
        tvIp.setText("Alamat IP HP ini: " + ips() + "\nPort: " + PORT);
    }

    private void setReceiveUi(boolean on) {
        btnReceive.setText(on ? "BERHENTI MENERIMA" : "MULAI TERIMA");
        paint(btnReceive, on ? C_RED : C_GREEN);
        enable(btnSend, !on);
        enable(btnAuto, !on);
        etIp.setEnabled(!on);
    }

    private void setSendUi(boolean on) {
        btnSend.setText(on ? "BATAL" : "PILIH FILE & KIRIM");
        paint(btnSend, on ? C_RED : C_BLUE);
        enable(btnReceive, !on);
        enable(btnAuto, !on);
        etIp.setEnabled(!on);
    }

    private void status(String main, String detail) {
        ui.post(() -> {
            tvStatus.setText(main);
            tvDetail.setText(detail);
        });
    }

    private void resetBar() {
        ui.post(() -> bar.setProgress(0));
    }

    private void keepOn(boolean on) {
        ui.post(() -> {
            if (on) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
    }

    private void progress(String title, long done, long total, long t0) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastUi < 150 && done < total) return;
        lastUi = now;
        final int p = total > 0 ? (int) (done * 1000 / total) : 1000;
        long el = Math.max(1, now - t0);
        double bps = done * 1000.0 / el;
        String eta = (bps > 1 && total > done) ? " · sisa " + dur((long) ((total - done) / bps)) : "";
        final String d = fmt(done) + " / " + fmt(total) + " · " + fmt((long) bps) + "/dtk" + eta;
        ui.post(() -> {
            bar.setProgress(p);
            tvStatus.setText(title);
            tvDetail.setText(d);
        });
    }

    // ------------------------------------------------------------ receive

    private void toggleReceive() {
        if (receiving) {
            stopReceive();
            return;
        }
        if (sending) return;
        receiving = true;
        cancel = false;
        setReceiveUi(true);
        resetBar();
        new Thread(this::receiveLoop, "sharelup-recv").start();
    }

    private void stopReceive() {
        receiving = false;
        closeQuiet(server);
        closeQuiet(active);
        status("Penerima dihentikan", "");
    }

    private void receiveLoop() {
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(PORT));
            server = ss;
            while (receiving) {
                status("Menunggu pengirim...", "Alamat HP ini: " + ips() + " · port " + PORT);
                Socket s;
                try {
                    s = ss.accept();
                } catch (IOException e) {
                    break;
                }
                handleIncoming(s);
            }
        } catch (Exception e) {
            status("Gagal membuka penerima", msg(e));
        } finally {
            closeQuiet(server);
            server = null;
            receiving = false;
            ui.post(() -> setReceiveUi(false));
        }
    }

    private void handleIncoming(Socket s) {
        active = s;
        keepOn(true);
        Out cur = null;
        try {
            s.setSoTimeout(30000);
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), BUF));
            if (in.readInt() != MAGIC) throw new IOException("Koneksi bukan dari Sharelup");
            int n = in.readInt();
            long total = in.readLong();
            if (n < 1 || n > 5000 || total < 0) throw new IOException("Data tidak valid");

            long done = 0;
            long t0 = SystemClock.elapsedRealtime();
            byte[] buf = new byte[BUF];

            for (int i = 0; i < n; i++) {
                String name = safeName(in.readUTF());
                long size = in.readLong();
                if (size < 0) throw new IOException("Ukuran file tidak valid");
                cur = openOut(name);
                long left = size;
                while (left > 0) {
                    int r = in.read(buf, 0, (int) Math.min(buf.length, left));
                    if (r < 0) throw new EOFException("Koneksi terputus");
                    cur.os.write(buf, 0, r);
                    left -= r;
                    done += r;
                    progress("Menerima " + (i + 1) + "/" + n + ": " + name, done, total, t0);
                }
                cur.finish();
                cur = null;
            }

            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            out.writeInt(1);
            out.flush();

            long el = Math.max(1, SystemClock.elapsedRealtime() - t0);
            ui.post(() -> bar.setProgress(1000));
            status("Selesai: " + n + " file diterima",
                    "Tersimpan di Download/Sharelup · " + fmt(total)
                            + " · rata-rata " + fmt((long) (total * 1000.0 / el)) + "/dtk");
        } catch (Exception e) {
            if (cur != null) cur.abort();
            if (receiving) {
                status("Penerimaan gagal", msg(e));
            } else {
                status("Penerima dihentikan", "");
            }
        } finally {
            closeQuiet(s);
            active = null;
            keepOn(false);
        }
    }

    // ------------------------------------------------------------ send

    private void onSendClick() {
        if (sending) {
            cancel = true;
            closeQuiet(active);
            return;
        }
        String ip = etIp.getText().toString().trim();
        if (!Patterns.IP_ADDRESS.matcher(ip).matches()) {
            toast("Isi IP penerima dulu (tekan ISI IP OTOMATIS).");
            return;
        }
        Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        it.addCategory(Intent.CATEGORY_OPENABLE);
        it.setType("*/*");
        it.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(it, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;

        final List<Uri> uris = new ArrayList<>();
        android.content.ClipData cd = data.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) {
                Uri u = cd.getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (uris.isEmpty()) return;

        final String ip = etIp.getText().toString().trim();
        sending = true;
        cancel = false;
        setSendUi(true);
        resetBar();
        new Thread(() -> doSend(uris, ip), "sharelup-send").start();
    }

    private void doSend(List<Uri> uris, String ip) {
        Socket s = null;
        keepOn(true);
        try {
            int n = uris.size();
            String[] names = new String[n];
            long[] sizes = new long[n];
            long total = 0;
            for (int i = 0; i < n; i++) {
                meta(uris.get(i), names, sizes, i);
                if (sizes[i] < 0) throw new IOException("Ukuran file tidak diketahui: " + names[i]);
                total += sizes[i];
            }

            status("Menghubungkan ke " + ip + "...", "");
            s = new Socket();
            active = s;
            Network wn = wifiNet();
            if (wn != null) {
                try {
                    wn.bindSocket(s);
                } catch (Exception ignored) {
                }
            }
            s.connect(new InetSocketAddress(ip, PORT), 8000);

            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), BUF));
            out.writeInt(MAGIC);
            out.writeInt(n);
            out.writeLong(total);

            long done = 0;
            long t0 = SystemClock.elapsedRealtime();
            byte[] buf = new byte[BUF];

            for (int i = 0; i < n; i++) {
                out.writeUTF(names[i]);
                out.writeLong(sizes[i]);
                InputStream is = getContentResolver().openInputStream(uris.get(i));
                if (is == null) throw new IOException("Tidak bisa membuka: " + names[i]);
                try {
                    long left = sizes[i];
                    while (left > 0) {
                        int r = is.read(buf, 0, (int) Math.min(buf.length, left));
                        if (r < 0) break;
                        out.write(buf, 0, r);
                        left -= r;
                        done += r;
                        progress("Mengirim " + (i + 1) + "/" + n + ": " + names[i], done, total, t0);
                    }
                    if (left > 0) throw new IOException("File terpotong: " + names[i]);
                } finally {
                    is.close();
                }
            }
            out.flush();

            s.setSoTimeout(60000);
            int ack = new DataInputStream(s.getInputStream()).readInt();
            if (ack != 1) throw new IOException("Penerima tidak mengonfirmasi");

            long el = Math.max(1, SystemClock.elapsedRealtime() - t0);
            ui.post(() -> bar.setProgress(1000));
            status("Terkirim: " + n + " file",
                    fmt(total) + " · rata-rata " + fmt((long) (total * 1000.0 / el)) + "/dtk");
        } catch (Exception e) {
            if (cancel) {
                status("Dibatalkan", "");
            } else {
                status("Gagal mengirim: " + msg(e),
                        "Pastikan penerima sudah menekan MULAI TERIMA dan IP benar.");
            }
        } finally {
            closeQuiet(s);
            active = null;
            sending = false;
            keepOn(false);
            ui.post(() -> setSendUi(false));
        }
    }

    private void meta(Uri u, String[] names, long[] sizes, int i) {
        String name = null;
        long size = -1;
        Cursor c = null;
        try {
            c = getContentResolver().query(u,
                    new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE},
                    null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        if (size < 0) {
            try {
                AssetFileDescriptor a = getContentResolver().openAssetFileDescriptor(u, "r");
                if (a != null) {
                    size = a.getLength();
                    a.close();
                }
            } catch (Exception ignored) {
            }
        }
        if (name == null || name.isEmpty()) name = u.getLastPathSegment();
        names[i] = safeName(name == null ? "file" : name);
        sizes[i] = size;
    }

    // ------------------------------------------------------------ file output

    private class Out {
        OutputStream os;
        Uri uri;
        File file;

        void finish() throws IOException {
            os.close();
            if (uri != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, v, null, null);
            }
        }

        void abort() {
            try {
                if (os != null) os.close();
            } catch (Exception ignored) {
            }
            try {
                if (uri != null) {
                    getContentResolver().delete(uri, null, null);
                } else if (file != null) {
                    file.delete();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private Out openOut(String name) throws IOException {
        Out o = new Out();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime(name));
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sharelup");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            o.uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (o.uri == null) throw new IOException("Gagal membuat file di folder Download");
            OutputStream raw = getContentResolver().openOutputStream(o.uri);
            if (raw == null) throw new IOException("Gagal menulis file");
            o.os = new BufferedOutputStream(raw, BUF);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "Sharelup");
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IOException("Gagal membuat folder (izin penyimpanan belum diberikan?)");
            }
            File f = new File(dir, name);
            int k = 1;
            while (f.exists()) {
                f = new File(dir, "(" + k + ") " + name);
                k++;
            }
            o.file = f;
            o.os = new BufferedOutputStream(new FileOutputStream(f), BUF);
        }
        return o;
    }

    private String mime(String name) {
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length() - 1) {
            String m = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    // ------------------------------------------------------------ helpers

    private String safeName(String n) {
        if (n == null) return "file";
        n = n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (n.length() > 200) n = n.substring(n.length() - 200);
        if (n.isEmpty() || n.equals(".") || n.equals("..")) n = "file";
        return n;
    }

    private String msg(Exception e) {
        String m = e.getMessage();
        return m == null ? e.getClass().getSimpleName() : m;
    }

    private void closeQuiet(Closeable c) {
        try {
            if (c != null) c.close();
        } catch (Exception ignored) {
        }
    }

    private String fmt(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%.2f GB", b / 1073741824.0);
    }

    private String dur(long sec) {
        if (sec < 60) return sec + " dtk";
        if (sec < 3600) return (sec / 60) + " mnt " + (sec % 60) + " dtk";
        return (sec / 3600) + " jam " + ((sec % 3600) / 60) + " mnt";
    }

    private String ips() {
        StringBuilder sb = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (sb.length() > 0) sb.append(", ");
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return sb.length() == 0 ? "tidak terdeteksi" : sb.toString();
    }

    @SuppressWarnings("deprecation")
    private String gateway() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            int g = wm.getDhcpInfo().gateway;
            if (g == 0) return "";
            return (g & 0xFF) + "." + ((g >> 8) & 0xFF) + "." + ((g >> 16) & 0xFF) + "." + ((g >> 24) & 0xFF);
        } catch (Exception e) {
            return "";
        }
    }

    @SuppressWarnings("deprecation")
    private Network wifiNet() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n;
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
